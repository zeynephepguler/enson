<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <title></title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="{{ asset('css/ilk.css') }}" type="text/css">
  </head>

  <body>
    <div >
    <ul >
      <li><a href="/ogrencianasayfa">Ana sayfa</a></li>
      <li><a href="/basvurularim">Başvurularım</a></li>
      <li><a href="/basvuruyap">Başvuru Yap</a></li>
      <li><a href="/kisiselbilgiler">Kişisel Bilgiler</a></li>
      <li><a href="/">Çıkış</a></li>
    </ul>
  </div>
  </body>
</html>
