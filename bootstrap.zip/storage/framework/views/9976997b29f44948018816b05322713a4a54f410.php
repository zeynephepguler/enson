<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/ilk.css')); ?>">
  </head>


    <div class="üst">
      <img src="<?php echo e(asset('resimler/logorgb.png')); ?>" height="150px" width="150px" >

    </div>
    <div class="üst" >
      <center>
      KOCAELİ ÜNİVERSİTESİ YAZLAB PROJESİ</center>
    </div>


</html>
<?php /**PATH C:\Users\USER\github\enson\resources\views/layouts/header.blade.php ENDPATH**/ ?>