<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <title></title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="<?php echo e(asset('css/ilk.css')); ?>" type="text/css">
  </head>

  <body>
    <div >
    <ul >
      <li><a href="#">Ana sayfa</a></li>
      <li><a href="/adminbasvurular">Başvurular</a></li>
      <li><a href="#">Onaylanan Başvurular</a></li>
      <li><a href="#">Reddedilen Başvurular</a></li>
      <li><a href="#">Adimin yetkileri</a>
        <ul>
          <li><a href="#">incoder sıralama</a></li>
          <li><a href="#">preorder sıralama</a></li>
          <li><a href="#">bişeyorder</a></li>
          <li><a href="#">bigOnotasyonu</a></li>
           </ul>
      </li>
      <li><a href="/">Çıkış</a></li>
    </ul>
  </div>
  </body>
</html>
<?php /**PATH C:\Users\USER\github\son-master\resources\views/layouts/adminmenu.blade.php ENDPATH**/ ?>