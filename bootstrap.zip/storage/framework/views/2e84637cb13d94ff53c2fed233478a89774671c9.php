<?php $__env->startSection('content'); ?>

  <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Bilgilerim</title>
      <link rel="stylesheet" href="<?php echo e(asset('bootstrap-3.1.1/css/bootstrap.min.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('css/a.css')); ?>" type="text/css">
  </head>
  <body>
      <div class="container">
           <div class="row">
              <div class="col-md-6 col-md-offset-3">
                     <h4>Kişisel Bilgiler</h4><hr>
                     <img src="uploads/ogrenci/<?php echo e($LoggedUserInfo['image']); ?>" width="200px">
                     <table class="table table-hover">
                       <tr><td class="tab">Numara:</td> <td class="tab2"><?php echo e($LoggedUserInfo['no']); ?></td></tr>
                       <tr><td class="tab">İsim:</td> <td class="tab2"><?php echo e($LoggedUserInfo['ad']); ?></td></tr>
                       <tr><td class="tab">Soyisim:</td> <td class="tab2"><?php echo e($LoggedUserInfo['soyad']); ?></td></tr>
                       <tr><td class="tab">Tc:</td> <td class="tab2"><?php echo e($LoggedUserInfo['tc']); ?></td></tr>
                       <tr><td class="tab">Doğum Tarihi:</td> <td class="tab2"><?php echo e($LoggedUserInfo['tarih']); ?></td> </tr>
                       <tr><td class="tab">Telefon:</td> <td class="tab2"><?php echo e($LoggedUserInfo['telefon']); ?></td></tr>
                       <tr><td class="tab">E-mail:</td> <td class="tab2"><?php echo e($LoggedUserInfo['email']); ?> </td> </tr>
                       <tr><td class="tab">Sınıf:</td> <td class="tab2"><?php echo e($LoggedUserInfo['sinifsec']); ?> </td> </tr>
                       <tr><td class="tab">Adres:</td> <td class="tab2"><?php echo e($LoggedUserInfo['adres']); ?></td></tr>
                       <tr><td><a href="<?php echo e(route('cıkıs')); ?>">Logout</a></td> <td> </td></tr>
                     </table>
              </div>
           </div>
      </div>
  </body>
  </html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\github\enson\resources\views/layouts/kisiselbilgiler.blade.php ENDPATH**/ ?>