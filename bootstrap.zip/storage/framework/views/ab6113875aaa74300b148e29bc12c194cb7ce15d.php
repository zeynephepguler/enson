<?php $__env->startSection('content'); ?>
<body>
    <link rel="stylesheet" href="<?php echo e(asset('css/sec.css')); ?>" type="text/css">
<br>
<div>
<input type="button" class="bsvr renk" onclick="location='basvurucap'" value="Çap Başvurusu">
<input type="button" class="bsvr renk" onclick="location='basvuruytg'" value="Yatay Geçiş Başvurusu">
<input type="button" class="bsvr renk" onclick="location='basvurudgs'" value="Dikey Geçiş Başvurusu">
<input type="button" class="bsvr renk" onclick="location='basvuruintibak'" value="İntibak Başvurusu">
<input type="button" class="bsvr renk" onclick="location='basvuruyazokulu'" value="Yaz Okulu Başvurusu">
</div>

<div class="d2">
<label> Fakülte: </label>
<input name="ad" type="text" size="50px"> <br>
<label>  Bölüm : </label>
<input name="ad" type="text" size="50px"> <br>
<label> Numara:</label>
<input name="ad" type="text" size="50px"> <br> <br>
<label> Ekler: </label> <label>Trankript  Başarı Sıralaması </label>
</div>
<div >
  <form action="<?php echo e(route('capkontrol')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="basvuru turu" value="cap">

    <input type="hidden" name="cap" value="başvuru talebi var">
  
    <input type="hidden" name="ogrencino" value="<?php echo e($LoggedUserInfo['no']); ?>">
    <input type="file" name="dilekce" required class="course form-control"> <br>

    <button type="submit" class="btn btn-block btn-primary" name="button" >Başvuru Yap</button>

  </form>
</div>
<?php $__env->stopSection(); ?>
<?php

?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\github\son-master\resources\views/layouts/basvurucap.blade.php ENDPATH**/ ?>