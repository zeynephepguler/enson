<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
    <center>
            <div >
          <?php echo $__env->yieldContent('content'); ?>
        </div>
        <div >
          <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
  </body>
</html>
<?php /**PATH C:\Users\USER\github\son-master\resources\views/layouts/anasayfaduzen.blade.php ENDPATH**/ ?>