
<?php $__env->startSection('content'); ?>
<body>
    <link rel="stylesheet" href="<?php echo e(asset('css/sec.css')); ?>" type="text/css">
<br>
<div>
<input type="button" class="bsvr renk" onclick="location='adminbasvurucap'" value="Çap Başvurusu">
<input type="button" class="bsvr renk" onclick="location='adminbasvuruytg'" value="Yatay Geçiş Başvurusu">
<input type="button" class="bsvr renk" onclick="location='adminbasvurudgs'" value="Dikey Geçiş Başvurusu">
<input type="button" class="bsvr renk" onclick="location='adminbasvuruintibak'" value="İntibak Başvurusu">
<input type="button" class="bsvr renk" onclick="location='adminbasvuruyazokulu'" value="Yaz Okulu Başvurusu">
</div>
<table border="1">
    <tr>
        <td>ogrencino</td>
        <td>dilekce</td>
        <td>Başvuru Durumu</td>
    </tr>
  <?php $__currentLoopData = $basvurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basvuru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($basvuru['ogrencino']); ?></td>
      <td><a href="uploads/dilekce/<?php echo e($basvuru['dilekce']); ?>">indir</a></td>
      <td><?php echo e($basvuru['dikeygecis']); ?></td>

    </tr>



  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admintema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\github\enson\resources\views/layouts/adminbasvurudgs.blade.php ENDPATH**/ ?>