<?php $__env->startSection('content'); ?>
<body>
    <link rel="stylesheet" href="<?php echo e(asset('css/a.css')); ?>" type="text/css">

    <div class="div1" >
    <ul ><left>
      <li><a href="/kayitol">Kayıt Ol</a></li>
      <li><a href="/ogrencigiris">Giriş Yap</a></li>
      <li><a href="/sifremiunuttum">Şifremi Unuttum</a></li>
    </ul>
    </div>

<form action="<?php echo e(route('kayitkontrol')); ?>" method="post">
            <?php if(Session::get('fail')): ?>
               <div class="alert alert-danger">
                  <?php echo e(Session::get('fail')); ?>

               </div>
            <?php endif; ?>

           <?php echo csrf_field(); ?>
              <div class="form-group">
                 <br>
                 <input type="text" class="form-control" name="no" placeholder="Numaranızı Giriniz" value="<?php echo e(old('no')); ?>">
                 <span class="text-danger"><?php $__errorArgs = ['no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
              </div>
              <div class="form-group">
                 <input type="password" class="form-control" name="sifre" placeholder="Şifrenizi Giriniz">
                 <span class="text-danger"><?php $__errorArgs = ['sifre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
              </div><br>
              <button type="submit" class="btn btn-block btn-primary">Giriş Yap</button>
              <br>
              <a href="<?php echo e(route('kayitol')); ?>">Önce Kayıt Olmayı Deneyin</a>
           </form>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.anasayfaduzen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\github\son-master\resources\views/layouts/ogrencigiris.blade.php ENDPATH**/ ?>